// SFX সিন্থেসাইজার: কোনো ডাউনলোড নেই, সম্পূর্ণ ডিটারমিনিস্টিক। আউটপুট: public/sfx/*.wav (16-bit mono, 44.1kHz)
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const SR = 44100;
const OUT = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "public", "sfx");
fs.mkdirSync(OUT, {recursive: true});

const rng = (seed) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
const buf = (d) => new Float32Array(Math.round(d * SR));

const lowpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < x.length; i++) {
    y += a * (x[i] - y);
    x[i] = y;
  }
  return x;
};
const highpass = (x, fc) => {
  const a = 1 - Math.exp((-2 * Math.PI * fc) / SR);
  let y = 0;
  for (let i = 0; i < x.length; i++) {
    y += a * (x[i] - y);
    x[i] = x[i] - y;
  }
  return x;
};
// খুব ছোট রিভার্ব: তিনটি comb
const tinyReverb = (x, mix = 0.6) => {
  const ds = [0.019, 0.027, 0.037].map((d) => Math.round(d * SR));
  const fb = 0.28;
  const avg = new Float32Array(x.length);
  for (const d of ds) {
    const c = new Float32Array(x.length);
    for (let i = 0; i < x.length; i++) {
      c[i] = x[i] + (i >= d ? fb * c[i - d] : 0);
      avg[i] += c[i] / ds.length;
    }
  }
  for (let i = 0; i < x.length; i++) x[i] = x[i] + mix * (avg[i] - x[i]);
  return x;
};
const fadeOut = (x, sec) => {
  const n = Math.round(sec * SR);
  for (let i = 0; i < n && i < x.length; i++) {
    const k = x.length - 1 - i;
    x[k] *= 0.5 - 0.5 * Math.cos((Math.PI * i) / n);
  }
  return x;
};
const finish = (x, lp) => {
  lowpass(x, lp);
  tinyReverb(x);
  lowpass(x, lp + 1500);
  fadeOut(x, 0.04);
  return x;
};

// pop = দ্রুত নিচে নামা pitch সহ sine + ছোট envelope
const pop = () => {
  const x = buf(0.22);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (170 + 420 * Math.exp(-t / 0.03))) / SR;
    const env = Math.min(1, t / 0.004) * Math.exp(-t / 0.055);
    x[i] = (Math.sin(ph) + 0.18 * Math.sin(2 * ph)) * env;
  }
  return finish(x, 5200);
};

// click = high-pass করা ছোট noise burst
const click = () => {
  const x = buf(0.12);
  const n = rng(7);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const env = Math.min(1, t / 0.0012) * Math.exp(-t / 0.0055);
    x[i] = (n() * 2 - 1) * env;
  }
  highpass(x, 1800);
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    x[i] += 0.25 * Math.sin(2 * Math.PI * 2600 * t) * Math.exp(-t / 0.003);
  }
  return finish(x, 7000);
};

// whoosh = band-pass noise sweep + fade in/out
const whoosh = () => {
  const d = 0.75;
  const x = buf(d);
  const n = rng(21);
  let low = 0;
  let band = 0;
  const Q = 1.1;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    const fc = 350 * Math.pow(3200 / 350, t / d);
    const f = 2 * Math.sin((Math.PI * fc) / SR);
    const inp = n() * 2 - 1;
    const high = inp - low - band / Q;
    band += f * high;
    low += f * band;
    const a = Math.min(1, t / 0.28);
    const b = Math.min(1, (d - t) / 0.42);
    const sm = (u) => u * u * (3 - 2 * u);
    x[i] = band * sm(a) * sm(Math.max(0, b));
  }
  return finish(x, 6000);
};

// নরম সফট থাড
const thud = () => {
  const x = buf(0.4);
  let ph = 0;
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (48 + 62 * Math.exp(-t / 0.07))) / SR;
    x[i] = Math.sin(ph) * Math.min(1, t / 0.01) * Math.exp(-t / 0.11);
  }
  return finish(x, 900);
};

// ছোট সফট pluck (নরম ওভারটোনসহ)
const pluck = () => {
  const x = buf(0.5);
  const base = 587.33;
  const parts = [[1, 1], [2, 0.38], [3.01, 0.16], [4.03, 0.07]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let v = 0;
    for (const [k, a] of parts) v += a * Math.sin(2 * Math.PI * base * k * t) * Math.exp(-t / (0.16 / Math.pow(k, 0.7)));
    x[i] = v * Math.min(1, t / 0.004);
  }
  return finish(x, 4800);
};

// নরম chime
const chime = () => {
  const x = buf(0.5);
  const base = 784;
  const parts = [[1, 1, 0.2], [2.4, 0.28, 0.12], [4.1, 0.1, 0.07]];
  for (let i = 0; i < x.length; i++) {
    const t = i / SR;
    let v = 0;
    for (const [k, a, tau] of parts) v += a * Math.sin(2 * Math.PI * base * k * t) * Math.exp(-t / tau);
    x[i] = v * Math.min(1, t / 0.006);
  }
  return finish(x, 6500);
};

const TARGET_RMS = 0.12;
const PEAK_CAP = 0.5;
const normalize = (x) => {
  let sum = 0;
  let peak = 0;
  for (const v of x) {
    sum += v * v;
    peak = Math.max(peak, Math.abs(v));
  }
  const rms = Math.sqrt(sum / x.length);
  const g = Math.min(TARGET_RMS / rms, PEAK_CAP / peak);
  for (let i = 0; i < x.length; i++) x[i] *= g;
  return x;
};

const writeWav = (name, x) => {
  const b = Buffer.alloc(44 + x.length * 2);
  b.write("RIFF", 0);
  b.writeUInt32LE(36 + x.length * 2, 4);
  b.write("WAVEfmt ", 8);
  b.writeUInt32LE(16, 16);
  b.writeUInt16LE(1, 20);
  b.writeUInt16LE(1, 22);
  b.writeUInt32LE(SR, 24);
  b.writeUInt32LE(SR * 2, 28);
  b.writeUInt16LE(2, 32);
  b.writeUInt16LE(16, 34);
  b.write("data", 36);
  b.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) b.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(x[i] * 32767))), 44 + i * 2);
  fs.writeFileSync(path.join(OUT, name + ".wav"), b);
};

const kit = {pop, click, whoosh, thud, pluck, chime};
for (const [name, fn] of Object.entries(kit)) writeWav(name, normalize(fn()));

// যাচাই: ফাইল পড়ে দৈর্ঘ্য, peak, RMS, clipping
console.log("name     dur(s)  peak(dBFS)  rms(dBFS)  clipped");
for (const name of Object.keys(kit)) {
  const b = fs.readFileSync(path.join(OUT, name + ".wav"));
  const n = (b.length - 44) / 2;
  let peak = 0;
  let sum = 0;
  let clipped = 0;
  for (let i = 0; i < n; i++) {
    const v = b.readInt16LE(44 + i * 2) / 32768;
    peak = Math.max(peak, Math.abs(v));
    sum += v * v;
    if (Math.abs(v) >= 0.999) clipped++;
  }
  const db = (v) => (20 * Math.log10(v)).toFixed(1);
  console.log(name.padEnd(8), (n / SR).toFixed(2).padStart(6), db(peak).padStart(11), db(Math.sqrt(sum / n)).padStart(10), String(clipped).padStart(8));
}
