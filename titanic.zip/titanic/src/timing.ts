// সব টাইমিং SRT থেকে। এখানে কোনো ফ্রেম নম্বর হাতে বসানো নেই।
import {SRT_TEXT} from "./script";

export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;
export const LEAD = 5; // ভিজ্যুয়াল সংশ্লিষ্ট কথার ৪–৬ ফ্রেম আগে ঢোকে
export const TAIL = Math.round(0.8 * FPS); // শেষ cue-এর পর ধীর ফেডের জন্য

export type Cue = {
  index: number;
  text: string;
  startMs: number;
  endMs: number;
  start: number; // ফ্রেম
  end: number; // ফ্রেম
  dur: number; // ফ্রেম
};

const toMs = (t: string): number => {
  const m = /(\d+):(\d+):(\d+)[,.](\d+)/.exec(t.trim());
  if (!m) throw new Error("SRT সময় পড়া যায়নি: " + t);
  return ((Number(m[1]) * 60 + Number(m[2])) * 60 + Number(m[3])) * 1000 + Number(m[4]);
};

export const parseSrt = (src: string): Cue[] =>
  src
    .replace(/\r/g, "")
    .replace(/^\uFEFF/, "")
    .trim()
    .split(/\n\s*\n/)
    .map((block) => {
      const lines = block.split("\n").map((l) => l.trim()).filter(Boolean);
      const [a, b] = lines[1].split("-->");
      const startMs = toMs(a);
      const endMs = toMs(b);
      const start = Math.round((startMs / 1000) * FPS);
      const end = Math.round((endMs / 1000) * FPS);
      return {
        index: Number(lines[0]),
        text: lines.slice(2).join(" "),
        startMs,
        endMs,
        start,
        end,
        dur: end - start,
      };
    });

export const CUES = parseSrt(SRT_TEXT);
export const DURATION = CUES[CUES.length - 1].end + TAIL;

export const cueAt = (n: number): Cue => {
  const c = CUES.find((x) => x.index === n);
  if (!c) throw new Error("cue নেই: " + n);
  return c;
};

/**
 * cue n-এর ভেতরে k-তম (০-ভিত্তিক) আইটেম, মোট `of` টি আইটেম থাকলে cue-র সময়ে সমান ব্যবধানে বসে।
 * ফল = সেই মুহূর্তের LEAD ফ্রেম আগে।
 */
export const slot = (n: number, k = 0, of = 1): number => {
  const c = cueAt(n);
  return Math.max(0, Math.round(c.start + (c.dur * k) / of) - LEAD);
};
