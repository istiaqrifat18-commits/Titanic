import React, {useEffect, useState} from "react";
import {Audio, continueRender, delayRender, staticFile} from "remotion";

/**
 * public/voiceover.mp3 থাকলে প্রিভিউ ও রেন্ডারে আপনাআপনি যুক্ত হয়; না থাকলে কিছুই করে না।
 */
export const VoiceOver: React.FC = () => {
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => delayRender("voiceover-check"));
  useEffect(() => {
    let alive = true;
    fetch(staticFile("voiceover.mp3"))
      .then((r) => {
        const ct = r.headers.get("content-type") || "";
        if (alive) setOk(r.ok && !ct.includes("text/html"));
      })
      .catch(() => {
        if (alive) setOk(false);
      })
      .finally(() => continueRender(handle));
    return () => {
      alive = false;
    };
  }, [handle]);
  return ok ? <Audio src={staticFile("voiceover.mp3")} volume={1} /> : null;
};
