import React from "react";
import {AbsoluteFill, useCurrentFrame} from "remotion";
import {theme} from "../theme";

export const Backdrop: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: `linear-gradient(180deg, ${theme.colors.bg} 0%, ${theme.colors.bgAlt} 55%, ${theme.colors.bg} 100%)`}}>
      <div style={{position: "absolute", width: 1400, height: 1400, borderRadius: "50%", top: -640, left: -420 + Math.sin(frame / 90) * 50, filter: "blur(60px)", background: `radial-gradient(circle, ${theme.colors.glowCool}, transparent 62%)`, opacity: 0.45}} />
      <div style={{position: "absolute", width: 1100, height: 1100, borderRadius: "50%", bottom: -560, right: -300 - Math.cos(frame / 110) * 40, filter: "blur(80px)", background: `radial-gradient(circle, ${theme.colors.glowHero}, transparent 65%)`, opacity: 0.08}} />
    </AbsoluteFill>
  );
};
