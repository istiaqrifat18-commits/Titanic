import React from "react";
import {Audio, Sequence, staticFile} from "remotion";
import {FPS, slot} from "../timing";
import {T} from "../scenes/times";

// শুধু SFX (মিউজিক/ভয়েসওভার নয়)। সীমিত ৬টি সাউন্ড; বিষয়ের গাম্ভীর্যে সংযত, সামান্য নিচু pitch।
type Name = "whoosh" | "pop" | "click" | "thud" | "pluck" | "chime";
type Ev = {at: number; name: Name; vol: number; rate?: number};
const s = slot;

export const SFX_EVENTS: Ev[] = [
  {at: 1, name: "whoosh", vol: 0.22, rate: 0.95}, // জাহাজ ঢোকে
  {at: s(2, 0, 3), name: "whoosh", vol: 0.2, rate: 1.0}, // তারিখ
  {at: T.depart + 3, name: "pop", vol: 0.24, rate: 1.0}, // যাত্রা শুরু
  {at: T.title + 4, name: "pluck", vol: 0.3, rate: 0.95}, // "টাইটানিক"
  {at: T.hud + 6, name: "click", vol: 0.26, rate: 0.95}, // ১০ এপ্রিল নোড
  {at: T.night + 4, name: "click", vol: 0.26, rate: 1.05}, // ১৪ এপ্রিল নোড
  {at: T.berg, name: "whoosh", vol: 0.2, rate: 0.85}, // বরফখণ্ড আসে
  {at: T.hit + 2, name: "thud", vol: 0.3, rate: 0.85}, // ধাক্কা (সংযত)
  {at: T.third + 14, name: "click", vol: 0.26, rate: 0.9}, // ১৫ এপ্রিল নোড
  {at: T.sink, name: "whoosh", vol: 0.2, rate: 0.8}, // ডুবতে শুরু
  {at: T.number + 4, name: "pop", vol: 0.24, rate: 0.85}, // সংখ্যা
  {at: T.hudOut + 4, name: "thud", vol: 0.22, rate: 1.05}, // মূল বার্তা
  {at: T.claim + 16, name: "click", vol: 0.26, rate: 0.88}, // "ডুববে না" কাটা
  {at: T.final + 4, name: "chime", vol: 0.28, rate: 0.85}, // সমাপ্তি
];

export const Sfx: React.FC = () => (
  <>
    {SFX_EVENTS.map((e, i) => (
      <Sequence key={i} from={e.at} durationInFrames={Math.ceil(FPS * 1.1)} layout="none">
        <Audio src={staticFile(`sfx/${e.name}.wav`)} volume={e.vol} playbackRate={e.rate ?? 1} />
      </Sequence>
    ))}
  </>
);
