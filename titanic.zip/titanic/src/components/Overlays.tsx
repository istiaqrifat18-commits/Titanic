import React from "react";
import {AbsoluteFill, Sequence, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {cl} from "../util";
import {DURATION} from "../timing";

export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.grade, mixBlendMode: "soft-light", opacity: 0.14}} />
    <AbsoluteFill style={{background: "linear-gradient(180deg, rgba(0,0,0,0.12), transparent 28%, transparent 72%, rgba(0,0,0,0.2))"}} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: noise,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.06,
        mixBlendMode: "overlay",
      }}
    />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 56%, rgba(0,0,0,0.42) 100%)"}} />
);

const SweepBody: React.FC = () => {
  const f = useCurrentFrame();
  const x = interpolate(f, [0, 18], [-1500, 1500], {easing: theme.ease.inOut, ...cl});
  const o = interpolate(f, [0, 6, 14, 19], [0, 0.26, 0.26, 0], cl);
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        opacity: o,
        transform: `translateX(${x}px) skewX(-18deg)`,
        background: `linear-gradient(90deg, transparent 38%, ${theme.colors.sweep} 50%, transparent 62%)`,
      }}
    />
  );
};

/** সিন ট্রানজিশনের হালকা আলোর সোয়াইপ (১৯ ফ্রেম) */
export const Sweep: React.FC<{at: number}> = ({at}) => (
  <Sequence from={at} durationInFrames={20} layout="none">
    <SweepBody />
  </Sequence>
);

/** শেষ ফ্রেমগুলোতে নরম ফেড-আউট */
export const FadeOut: React.FC = () => {
  const f = useCurrentFrame();
  const o = interpolate(f, [DURATION - 16, DURATION - 1], [0, 1], {easing: theme.ease.in, ...cl});
  return <AbsoluteFill style={{background: theme.colors.bg, opacity: o, pointerEvents: "none"}} />;
};
