import React from "react";
import {interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {cl} from "../util";
const STRIKE_AFTER = 14;

// বাংলা টেক্সট কখনো অক্ষর ধরে ভাঙা হয় না: বিভাজন শুধু স্পেসে (শব্দ), letterSpacing 0।
export type Part = {t: string; c?: string; g?: string; strike?: boolean};

type Props = {
  parts: Part[];
  size: number;
  delay?: number;
  per?: number;
  color?: string;
  weight?: number;
  maxWidth?: number;
};

export const WordReveal: React.FC<Props> = ({parts, size, delay = 0, per = 3, color = theme.colors.text, weight = 700, maxWidth = 960}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const words = parts.flatMap((p) =>
    p.t
      .split(" ")
      .filter(Boolean)
      .map((w) => ({w, c: p.c ?? color, g: p.g, strike: !!p.strike}))
  );
  return (
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        columnGap: Math.round(size * 0.26),
        rowGap: Math.round(size * 0.02),
        maxWidth,
        fontFamily: theme.fonts.display,
        fontWeight: weight,
        fontSize: size,
        lineHeight: 1.4,
        letterSpacing: 0,
        textAlign: "center",
        color,
      }}
    >
      {words.map((o, i) => {
        const start = delay + i * per;
        const p = spring({frame: frame - start, fps, config: theme.spring.snappy});
        const q = Math.min(1, Math.max(0, p));
        const sp = o.strike ? interpolate(frame - start - STRIKE_AFTER, [0, 10], [0, 1], {easing: theme.ease.out, ...cl}) : 0;
        return (
          <span
            key={i}
            style={{
              display: "inline-block",
              position: "relative",
              color: o.c,
              opacity: q,
              transform: `translateY(${(1 - p) * 28}px) scale(${0.92 + 0.08 * p})`,
              filter: `blur(${Math.max(0, 1 - p) * 6}px)`,
              textShadow: o.g ? `0 0 36px ${o.g}, ${theme.shadow.text}` : theme.shadow.text,
            }}
          >
            {o.w}
            {o.strike ? (
              <span
                style={{
                  position: "absolute",
                  left: -8,
                  right: -8,
                  top: "52%",
                  height: Math.max(5, Math.round(size * 0.07)),
                  borderRadius: 4,
                  background: theme.colors.hero,
                  transformOrigin: "0% 50%",
                  transform: `scaleX(${sp})`,
                }}
              />
            ) : null}
          </span>
        );
      })}
    </div>
  );
};

/** ছোট ইংরেজি টেকনিক্যাল ট্যাগ (Gravity / Velocity / Orbit) */
export const Tag: React.FC<{label: string; color?: string; delay?: number}> = ({label, color = theme.colors.textDim, delay = 0}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = spring({frame: frame - delay, fps, config: theme.spring.smooth});
  return (
    <div
      style={{
        fontFamily: theme.fonts.display,
        fontWeight: 600,
        fontSize: 36,
        letterSpacing: 0,
        color,
        opacity: Math.min(1, p),
        transform: `translateY(${(1 - p) * 16}px)`,
        marginBottom: 6,
      }}
    >
      {label}
    </div>
  );
};
