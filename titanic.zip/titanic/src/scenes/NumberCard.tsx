import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {cl, fmtBn, win} from "../util";
import {slot} from "../timing";
import {T} from "./times";

const {colors: c} = theme;
const FONT = {fontFamily: theme.fonts.display, letterSpacing: 0, lineHeight: 1.3, textAlign: "center"} as const;
const OUT = slot(10, 0, 3);

/** প্রায় ১,৫০০ মানুষ (সংখ্যা স্ক্রিপ্ট থেকে: "এক হাজার পাঁচশো") */
export const NumberCard: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const o = win(frame, T.number, OUT, 16, 12);
  if (o <= 0.01) return null;
  const p = Math.min(1, spring({frame: frame - T.number, fps, config: theme.spring.soft}));
  const n = Math.round(1500 * interpolate(frame, [T.number + 6, T.number + 52], [0, 1], {easing: theme.ease.out, ...cl}));
  return (
    <AbsoluteFill style={{pointerEvents: "none", alignItems: "center", justifyContent: "center", opacity: o}}>
      <div style={{display: "flex", flexDirection: "column", alignItems: "center", transform: `translateY(${(1 - p) * 30 + 50}px)`}}>
        <div style={{...FONT, fontSize: 52, fontWeight: 600, color: c.textDim}}>প্রায়</div>
        <div style={{...FONT, fontSize: 190, fontWeight: 700, color: c.hero, textShadow: `0 0 50px ${c.glowHero}`, fontVariantNumeric: "tabular-nums"}}>{fmtBn(n)}</div>
        <div style={{...FONT, fontSize: 72, fontWeight: 700, color: c.text, textShadow: theme.shadow.text}}>মানুষ</div>
      </div>
    </AbsoluteFill>
  );
};
