import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {cl, lerpColor, mulberry} from "../util";
import {HEIGHT, WIDTH} from "../timing";
import {T} from "./times";

const {colors: c} = theme;
const WL = 1190; // জলরেখা
const BAND_TOP = 780;
const BAND_END = 1570;
const SHIP_X = 170;
const SHIP_W = 610;

const STARS = (() => {
  const r = mulberry(1912);
  return Array.from({length: 56}, () => ({x: r() * WIDTH, y: BAND_TOP + 40 + r() * (WL - BAND_TOP - 90), s: 1.5 + r() * 2.6, ph: r() * 6.28}));
})();
const WINDOWS = (() => {
  const r = mulberry(15);
  return Array.from({length: 27}, (_, i) => ({x: 58 + i * 17.5, fl: r() * 6.28, row2: i % 3 === 0}));
})();
const SHARDS = (() => {
  const r = mulberry(404);
  return Array.from({length: 9}, () => ({vx: -2 - r() * 5, vy: -3 - r() * 5, s: 4 + r() * 6}));
})();

const wave = (y0: number, amp: number, len: number, speed: number, f: number, ph: number) => {
  let d = `M0 ${BAND_END + 40}`;
  for (let x = 0; x <= WIDTH + 20; x += 20) d += ` L${x} ${(y0 + amp * Math.sin(x / len + f * speed + ph)).toFixed(1)}`;
  return d + ` L${WIDTH + 20} ${BAND_END + 40} Z`;
};

export const SeaStage: React.FC = () => {
  const frame = useCurrentFrame();

  // সময়-নির্ভর অবস্থা (সবই SRT-থেকে পাওয়া T থেকে)
  const night = interpolate(frame, [T.night, T.night + 45], [0, 1], {easing: theme.ease.inOut, ...cl});
  const shipSlide = interpolate(frame, [T.shipIn, T.shipIn + 100], [-720, 0], {easing: theme.ease.out, ...cl});
  const cruise = interpolate(frame, [T.depart, T.depart + 40], [1, 2.2], cl);
  const bob = Math.sin(frame / 30) * 5;
  const rock = Math.sin(frame / 50) * 0.7;
  const tilt = interpolate(frame, [T.list, T.panic + 60, T.sink, T.number], [0, 9, 26, 52], {easing: theme.ease.inOut, ...cl});
  const sinkY = interpolate(frame, [T.sink, T.number + 60], [0, 640], {easing: theme.ease.inOut, ...cl});
  const lights = interpolate(frame, [T.panic, T.sink, T.sink + 50], [1, 0.55, 0.05], cl) * (frame >= T.panic && frame < T.sink ? 0.75 + 0.25 * Math.sin(frame / 3) : 1);
  const bergX = interpolate(frame, [T.berg, T.hit], [1420, 915], {easing: theme.ease.inOut, ...cl});

  // ধাক্কা
  const th = frame - T.hit;
  const shake = th >= 0 ? 7 * Math.exp(-th / 10) : 0;
  const shx = Math.sin(th * 2.1) * shake;
  const shy = Math.cos(th * 2.9) * shake;

  const skyTop = lerpColor(c.skyDuskTop, c.skyNightTop, night);
  const skyHor = lerpColor(c.skyDuskHorizon, c.skyNightHorizon, night);
  const starO = interpolate(night, [0.3, 1], [0, 1], cl);

  const fin = interpolate(frame, [T.final, T.final + 30], [1, 0.16], {easing: theme.ease.inOut, ...cl});
  const sx = SHIP_X + shipSlide;
  const sy = WL + bob;

  return (
    <AbsoluteFill style={{pointerEvents: "none", opacity: fin}}>
      <svg
        width={WIDTH}
        height={HEIGHT}
        viewBox={`0 0 ${WIDTH} ${HEIGHT}`}
        style={{position: "absolute", left: 0, top: 0, WebkitMaskImage: `linear-gradient(to bottom, transparent ${BAND_TOP}px, #000 ${BAND_TOP + 110}px, #000 ${BAND_END - 170}px, transparent ${BAND_END}px)`, maskImage: `linear-gradient(to bottom, transparent ${BAND_TOP}px, #000 ${BAND_TOP + 110}px, #000 ${BAND_END - 170}px, transparent ${BAND_END}px)`}}
      >
        <defs>
          <linearGradient id="sky" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={skyTop} />
            <stop offset="1" stopColor={skyHor} />
          </linearGradient>
          <radialGradient id="sunGlow" cx="0.5" cy="0.5" r="0.5">
            <stop offset="0" stopColor={c.hero} stopOpacity="0.55" />
            <stop offset="1" stopColor={c.hero} stopOpacity="0" />
          </radialGradient>
        </defs>
        <g transform={`translate(${shx} ${shy})`}>
          <rect x="0" y={BAND_TOP} width={WIDTH} height={WL - BAND_TOP + 2} fill="url(#sky)" />
          <ellipse cx="760" cy={WL} rx="520" ry="230" fill="url(#sunGlow)" opacity={1 - night} />
          {STARS.map((s, i) => (
            <circle key={i} cx={s.x} cy={s.y} r={s.s / 2} fill={c.star} opacity={starO * (0.5 + 0.5 * Math.sin(frame / 25 + s.ph))} />
          ))}
          <path d={wave(WL, 5, 90, 0.035 * cruise, frame, 0)} fill={c.waveBack} />

          {/* বরফখণ্ড (জলের নিচের অংশ আবছা) */}
          <g transform={`translate(${bergX} ${WL})`}>
            <polygon points="-190,0 190,0 240,120 120,220 -60,245 -200,130" fill={c.iceDeep} opacity="0.4" />
            <polygon points="-170,0 -120,-62 -70,-96 -10,-190 -10,0" fill={c.iceFace} />
            <polygon points="-10,-190 40,-122 92,-142 152,-72 190,0 -10,0" fill={c.iceShade} />
            <polygon points="-10,-190 -10,-60 20,-90 40,-122" fill={c.iceFace} opacity="0.55" />
          </g>

          {/* জাহাজ: স্টার্নের জলরেখা = (0,0); ধনুক ডানে */}
          <g transform={`translate(${sx} ${sy + sinkY}) rotate(${tilt + rock})`}>
            <line x1="200" y1="-150" x2="200" y2="-260" stroke={c.hullStripe} strokeWidth="3" opacity="0.5" />
            <polygon points="0,-70 560,-78 612,-80 592,-10 560,18 40,18 10,-20" fill={c.hull} />
            <rect x="12" y="-40" width="560" height="5" fill={c.hullStripe} opacity="0.7" />
            <rect x="60" y="-122" width="460" height="52" fill={c.upper} />
            <rect x="120" y="-152" width="340" height="30" fill={c.upper2} />
            {[150, 232, 314, 396].map((x) => (
              <g key={x}>
                <rect x={x} y="-232" width="36" height="82" fill={c.funnel} />
                <rect x={x} y="-232" width="36" height="14" fill={c.funnelTop} />
              </g>
            ))}
            {WINDOWS.map((w, i) => (
              <rect key={i} x={w.x} y={w.row2 ? -108 : -96} width="7" height="9" fill={c.window} opacity={lights * (0.55 + 0.45 * Math.sin(frame / 11 + w.fl)) * 0.95} />
            ))}
            <circle cx="40" cy="-52" r="0" fill={c.window} />
          </g>

          <path d={wave(WL + 24, 7, 70, 0.05 * cruise, frame, 1.7)} fill={c.waveMid} opacity="0.92" />
          <path d={wave(WL + 52, 9, 110, 0.065 * cruise, frame, 3.1)} fill={c.waveFront} opacity="0.96" />

          {/* ধাক্কার রিং ও বরফের কণা */}
          {th >= 0 && th < 34 && <circle cx={bergX - 170} cy={WL - 18} r={16 + th * 4.5} fill="none" stroke={c.pale} strokeWidth={5} opacity={(1 - th / 34) * 0.6} />}
          {th >= 0 &&
            th < 40 &&
            SHARDS.map((s, i) => <circle key={i} cx={bergX - 170 + s.vx * th} cy={WL - 30 + s.vy * th + 0.32 * th * th} r={s.s / 2} fill={c.iceFace} opacity={1 - th / 40} />)}
        </g>
      </svg>
    </AbsoluteFill>
  );
};
