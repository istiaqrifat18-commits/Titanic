import React from "react";
import {Sequence, interpolate, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {cl} from "../util";
import {DURATION, slot} from "../timing";
import {WordReveal} from "../components/Words";
import {T} from "./times";

const {colors: c} = theme;
const EXIT = 9;
const OVERLAP = 6;
const s = slot;
const TOP = {top: 300, h: 340};
const BOT = {top: 1430, h: 250};
const H = {color: c.hero, g: c.glowHero};

const BeatBody: React.FC<{top: number; h: number; children: React.ReactNode}> = ({top, h, children}) => {
  const frame = useCurrentFrame();
  const {durationInFrames} = useVideoConfig();
  const st = Math.max(1, durationInFrames - EXIT);
  const o = interpolate(frame, [st, durationInFrames - 1], [1, 0], {easing: theme.ease.in, ...cl});
  const y = interpolate(frame, [st, durationInFrames - 1], [0, -28], {easing: theme.ease.in, ...cl});
  return (
    <div style={{position: "absolute", left: 60, top, width: 960, height: h, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", opacity: o, transform: `translateY(${y}px)`}}>
      {children}
    </div>
  );
};

type Spec = {label: string; from: number; end?: number; node: React.ReactNode};
const W = (parts: {t: string; c?: string; g?: string; strike?: boolean}[], size: number, weight = 700) => <WordReveal parts={parts} size={size} weight={weight} />;

// ক্রমানুসারে; জোড় সূচক = উপরের জোন, বিজোড় = নিচের জোন (একই জোনের পরের বিটে প্রতিস্থাপিত)
const SPECS: Spec[] = [
  {label: "c1 · বিলাসবহুল", from: s(1, 0, 2), node: W([{t: "সবচেয়ে"}, {t: "বিলাসবহুল জাহাজ", ...H}], 96)},
  {label: "c1 · হারিয়ে", from: s(1, 1, 2), node: W([{t: "হারিয়ে গিয়েছিল?"}], 100)},
  {label: "c2 · তারিখ", from: s(2, 0, 3), node: W([{t: "১৯১২ সালের"}, {t: "১০ এপ্রিল", ...H}], 104)},
  {label: "c2 · সাউদাম্পটন", from: s(2, 1, 3), node: W([{t: "ইংল্যান্ডের সাউদাম্পটন"}], 84)},
  {label: "c2 · যাত্রা", from: s(2, 2, 3), node: W([{t: "যাত্রা শুরু"}], 116)},
  {label: "c3 · টাইটানিক", from: s(3, 0, 2), node: W([{t: "টাইটানিক", ...H}], 140)},
  {label: "c3 · নিরাপদ", from: s(3, 1, 2), node: W([{t: "সবচেয়ে নিরাপদ জাহাজ"}], 92)},
  {label: "c4 · ডুববে না", from: s(4, 0, 3), node: W([{t: "কখনো ডুববে না"}], 100)},
  {label: "c4 · চার দিন", from: s(4, 1, 3), node: W([{t: "মাত্র চার দিন পর"}], 96)},
  {label: "c4 · রাতে", from: s(4, 2, 3), node: W([{t: "১৪ এপ্রিল", ...H}, {t: "রাতে"}], 96)},
  {label: "c5 · আটলান্টিক", from: s(5, 0, 3), node: W([{t: "উত্তর আটলান্টিক মহাসাগরে"}], 84)},
  {label: "c5 · দুর্ঘটনা", from: s(5, 1, 3), node: W([{t: "ভয়ঙ্কর এক দুর্ঘটনা"}], 96)},
  {label: "c5 · বরফখণ্ড", from: s(5, 2, 3), node: W([{t: "বিশাল"}, {t: "বরফখণ্ড", ...H}], 112)},
  {label: "c6 · ধাক্কা", from: s(6, 0, 2), node: W([{t: "ধাক্কা খায়"}], 116)},
  {label: "c6 · পানি", from: s(6, 1, 2), node: W([{t: "জাহাজের ভেতরে"}, {t: "পানি ঢুকতে শুরু করে"}], 80)},
  {label: "c7 · আতঙ্ক", from: s(7, 0, 3), node: W([{t: "ছড়িয়ে পড়ে আতঙ্ক"}], 100)},
  {label: "c7 · লাইফ বোট", from: s(7, 1, 3), node: W([{t: "লাইফ বোটের অভাবে"}], 96)},
  {label: "c7 · বাঁচানো", from: s(7, 2, 3), node: W([{t: "সবাইকে বাঁচানো সম্ভব হয়নি", c: c.textDim}], 76, 600)},
  {label: "c8 · ১৫ এপ্রিল", from: s(8, 0, 3), node: W([{t: "১৫ এপ্রিল", ...H}], 116)},
  {label: "c8 · ২:২০", from: s(8, 1, 3), node: W([{t: "ভোর"}, {t: "২:২০", ...H}], 116)},
  {label: "c8 · হারিয়ে যায়", from: s(8, 2, 3), node: W([{t: "সমুদ্রের গভীরে"}, {t: "হারিয়ে যায়"}], 88)},
  {label: "c9 · প্রাণ হারান", from: s(9, 0, 2), node: W([{t: "প্রাণ হারান"}], 108)},
  {label: "c9 · অবাক", from: s(9, 1, 2), node: W([{t: "সবচেয়ে অবাক করা বিষয়"}], 92)},
  {label: "c10 · দাবি", from: s(10, 0, 3), node: W([{t: "কখনো ডুববে না", c: c.textDim, strike: true}], 96, 600)},
  {label: "c10 · প্রথম যাত্রা", from: s(10, 1, 3), node: W([{t: "প্রথম যাত্রাতেই"}], 104)},
  {label: "c10 · সমাধি", from: s(10, 2, 3), end: T.final + OVERLAP, node: W([{t: "সমাধি হয়ে গেল", ...H}], 104)},
  {label: "c11 · তলদেশে", from: s(11, 0, 2), end: T.final + OVERLAP, node: W([{t: "সমুদ্রের তলদেশে"}], 104)},
];

export const Beats: React.FC = () => (
  <>
    {SPECS.map((sp, i) => {
      const zone = i % 2 === 0 ? TOP : BOT;
      const next = SPECS[i + 2];
      const to = sp.end ?? (next ? next.from + OVERLAP : DURATION);
      return (
        <Sequence key={sp.label} name={sp.label} from={sp.from} durationInFrames={Math.max(EXIT + 2, to - sp.from)} layout="none">
          <BeatBody top={zone.top} h={zone.h}>
            {sp.node}
          </BeatBody>
        </Sequence>
      );
    })}
    {/* সমাপনী শিরোনাম: কেন্দ্রে */}
    <Sequence name="c11 · টাইটানিক আজও" from={T.final} durationInFrames={DURATION - T.final} layout="none">
      <BeatBody top={800} h={420}>
        <WordReveal parts={[{t: "টাইটানিক", ...H}]} size={150} per={5} />
        <div style={{height: 14}} />
        <WordReveal parts={[{t: "ইতিহাসের সবচেয়ে আলোচিত সামুদ্রিক দুর্ঘটনা", c: c.textDim}]} size={58} weight={600} delay={14} per={3} />
      </BeatBody>
    </Sequence>
  </>
);
