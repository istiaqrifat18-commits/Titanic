import React from "react";
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {cl} from "../util";
import {T} from "./times";

const {colors: c} = theme;
const Y = 700;
const XS = [190, 540, 890];
const FONT = {fontFamily: theme.fonts.display, letterSpacing: 0, lineHeight: 1.3, textAlign: "center"} as const;

const Node: React.FC<{x: number; at: number; date: string; active: boolean}> = ({x, at, date, active}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const p = Math.min(1.1, spring({frame: frame - at, fps, config: theme.spring.snappy}));
  if (p <= 0.01) return null;
  const q = Math.min(1, p);
  return (
    <>
      <div style={{position: "absolute", left: x - 14, top: Y - 14, width: 28, height: 28, borderRadius: "50%", background: active ? c.hero : c.text, boxShadow: active ? `0 0 26px ${c.glowHero}` : undefined, transform: `scale(${p})`}} />
      <div style={{position: "absolute", left: x - 150, top: Y + 26, width: 300, ...FONT, fontSize: 46, fontWeight: 700, color: active ? c.hero : c.textDim, opacity: q, transform: `translateY(${(1 - q) * -14}px)`}}>{date}</div>
    </>
  );
};

/** ১০ এপ্রিল → ("চার দিন পর") ১৪ এপ্রিল → ১৫ এপ্রিল */
export const Hud: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const out = interpolate(frame, [T.number - 12, T.number], [1, 0], {easing: theme.ease.in, ...cl});
  const inn = interpolate(frame, [T.hud, T.hud + 10], [0, 1], cl);
  const o = out * inn;
  if (o <= 0.01) return null;
  const l1 = interpolate(frame, [T.hud + 4, T.night], [0, 1], {easing: theme.ease.inOut, ...cl});
  const l2 = interpolate(frame, [T.third, T.third + 20], [0, 1], {easing: theme.ease.inOut, ...cl});
  const pill = Math.min(1, spring({frame: frame - (T.hud + 8), fps, config: theme.spring.smooth}));
  return (
    <AbsoluteFill style={{pointerEvents: "none", opacity: o}}>
      <div style={{position: "absolute", left: XS[0] + 14, top: Y - 2, width: (XS[1] - XS[0] - 28) * l1, height: 4, borderRadius: 2, background: c.textDim}} />
      <div style={{position: "absolute", left: XS[1] + 14, top: Y - 2, width: (XS[2] - XS[1] - 28) * l2, height: 4, borderRadius: 2, background: c.textDim}} />
      <div style={{position: "absolute", left: (XS[0] + XS[1]) / 2 - 105, top: Y - 28, width: 210, height: 56, borderRadius: 30, background: c.bg, border: `2px solid ${c.textDim}`, ...FONT, fontSize: 36, fontWeight: 600, lineHeight: "52px", color: c.text, opacity: pill, transform: `scale(${0.9 + 0.1 * pill})`}}>চার দিন পর</div>
      <Node x={XS[0]} at={T.hud} date="১০ এপ্রিল" active={false} />
      <Node x={XS[1]} at={T.night} date="১৪ এপ্রিল" active={frame < T.third} />
      <Node x={XS[2]} at={T.third + 14} date="১৫ এপ্রিল" active={frame >= T.third} />
    </AbsoluteFill>
  );
};
