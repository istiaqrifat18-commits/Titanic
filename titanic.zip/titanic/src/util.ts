import {interpolate} from "remotion";
import {theme} from "./theme";

export const cl = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

/** a থেকে b পর্যন্ত দৃশ্যমান উইন্ডো (0..1): ঢোকা ধীর (expo-out), বেরোনো দ্রুত। */
export const win = (f: number, a: number, b: number, inD = 14, outD = 10): number =>
  interpolate(f, [a, a + inD], [0, 1], {easing: theme.ease.out, ...cl}) *
  interpolate(f, [Math.max(a + inD, b - outD), Math.max(a + inD + 1, b)], [1, 0], {easing: theme.ease.in, ...cl});

const BN = "০১২৩৪৫৬৭৮৯";
export const toBn = (v: string | number): string => String(v).replace(/\d/g, (d) => BN[Number(d)]);
export const fmtBn = (n: number): string => toBn(n.toLocaleString("en-US"));

const hex = (h: string) => [parseInt(h.slice(1, 3), 16), parseInt(h.slice(3, 5), 16), parseInt(h.slice(5, 7), 16)];
export const lerpColor = (a: string, b: string, t: number): string => {
  const k = Math.min(1, Math.max(0, t));
  const [r1, g1, b1] = hex(a);
  const [r2, g2, b2] = hex(b);
  return `rgb(${Math.round(r1 + (r2 - r1) * k)},${Math.round(g1 + (g2 - g1) * k)},${Math.round(b1 + (b2 - b1) * k)})`;
};
export const mulberry = (seed: number) => () => {
  seed |= 0;
  seed = (seed + 0x6d2b79f5) | 0;
  let t = Math.imul(seed ^ (seed >>> 15), 1 | seed);
  t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
};
