import React from "react";
import {AbsoluteFill} from "remotion";
import {theme} from "./theme";
import {Backdrop} from "./components/Backdrop";
import {FadeOut, Grade, Grain, Sweep, Vignette} from "./components/Overlays";
import {Sfx} from "./components/Sfx";
import {VoiceOver} from "./components/VoiceOver";
import {SeaStage} from "./scenes/SeaStage";
import {Hud} from "./scenes/Hud";
import {NumberCard} from "./scenes/NumberCard";
import {Beats} from "./scenes/Beats";
import {T} from "./scenes/times";

// স্তর (নিচ থেকে উপরে): ব্যাকগ্রাউন্ড → স্টেজ/অ্যাসেট → টাইপ → গ্রেড → গ্রেইন+ভিনিয়েট
export const Main: React.FC = () => (
  <AbsoluteFill style={{backgroundColor: theme.colors.bg}}>
    <Backdrop />
    <SeaStage />
    <Hud />
    <NumberCard />
    <Beats />
    <Sweep at={T.night} />
    <Sweep at={T.number} />
    <Grade />
    <Grain />
    <Vignette />
    <FadeOut />
    <VoiceOver />
    <Sfx />
  </AbsoluteFill>
);
