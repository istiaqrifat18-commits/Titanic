// theme.ts — রঙ, ফন্ট, easing, spring-এর একমাত্র উৎস। কম্পোনেন্টে কোনো ইনলাইন hex নেই।
import {Easing} from "remotion";
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: বাংলা যুক্তাক্ষর/রেফ/কার/সংখ্যা ঠিকঠাক আসে। শিরোনামে সর্বোচ্চ কার্যকর ওজন = 700।
const loaded = loadFont("normal", {weights: ["600", "700"], subsets: ["bengali", "latin"]});

export const theme = {
  colors: {
    bg: "#050A14",
    bgAlt: "#0A1426",
    hero: "#E9B86B", // একমাত্র হাইলাইট: তারিখ, সংখ্যা, মূল শব্দ (জাহাজের আলোর সোনালি)
    text: "#EEF3F8",
    textDim: "#8FA0B5",
    glowHero: "rgba(233,184,107,0.40)",
    glowCool: "rgba(120,170,230,0.30)",
    sweep: "rgba(160,200,235,0.45)",
    grade: "#2B5CA8",
    panel: "rgba(255,255,255,0.045)",
    pale: "#EAF4FF",
    skyDuskTop: "#27385A",
    skyDuskHorizon: "#D49A6A",
    skyNightTop: "#030712",
    skyNightHorizon: "#0E1A33",
    star: "#DCE8F5",
    waveBack: "#0C2038",
    waveMid: "#091A30",
    waveFront: "#06121F",
    hull: "#0E1726",
    hullStripe: "#B8C4D3",
    upper: "#1B2A42",
    upper2: "#243756",
    funnel: "#C9A15A",
    funnelTop: "#0A0F18",
    window: "#F6D58E",
    iceFace: "#DCEBF7",
    iceShade: "#9DB6CC",
    iceDeep: "#5C7C99",
  },
  fonts: {
    display: `${loaded.fontFamily}, 'Noto Sans Bengali', 'Hind Siliguri', sans-serif`,
  },
  shadow: {text: "0 4px 28px rgba(0,0,0,0.6)"},
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    soft: {damping: 22, stiffness: 120, mass: 0.9},
  },
} as const;
